//import 'dart:html';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
//import 'package:firebase_core/firebase_core.dart';
//import 'package:firebase_auth/firebase_auth.dart';

//final FirebaseAuth _auth = FirebaseAuth.instance;
final GoogleSignIn googleSignIn = GoogleSignIn();

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool isAuth = false;

  @override
  void initState() {
    super.initState();
    // Detects when user signed in
    googleSignIn.onCurrentUserChanged.listen((account) {
      if (account != null) {
        print('Account : $account');
        setState(() {
          isAuth = true;
        });
      }
      setState(() {
        isAuth = false;
      });
      //   handleSignIn(account);
      // }, onError: (err) {
      //   print('Error signing in: $err');
      // });
      // // Reauthenticate user when app is opened
      // googleSignIn.signInSilently(suppressErrors: false).then((account) {
      //   handleSignIn(account);
      // }).catchError((err) {
      //   print('Error signing in: $err');
    });
  }

  // handleSignIn(GoogleSignInAccount account) {
  //   // ignore: unnecessary_null_comparison
  //   if (account != null) {
  //     print('User signed in!: $account');
  //     setState(() {
  //       isAuth = true;
  //     });
  //   } else {
  //     setState(() {
  //       isAuth = false;
  //     });
  //   }
  // }

  login() {
    googleSignIn.signIn();
  }

  logout() {
    googleSignIn.signOut();
  }

  Widget buildAuthScreen() {
    return RaisedButton(
      child: Text('Logout'),
      onPressed: logout,
    );
  }

  Scaffold buildUnAuthScreen() {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).primaryColor,
              Theme.of(context).accentColor,
            ],
          ),
        ),
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            ShaderMask(
              shaderCallback: (Rect bounds) {
                return RadialGradient(
                  center: Alignment.topLeft,
                  radius: 1.0,
                  colors: <Color>[Colors.redAccent, Colors.deepOrange.shade900],
                  tileMode: TileMode.mirror,
                ).createShader(bounds);
              },
              child: const Text(
                'InPhoMeet',
                style: TextStyle(
                  fontFamily: "transformers",
                  fontSize: 50.0,
                  color: Colors.deepOrange,
                ),
              ),
            ),
            Text(''),
            Text(''),
            Text(''),
            Image.network(
              'https://cdn.discordapp.com/attachments/554896306863341568/789406160372891658/rainbow.gif',
              fit: BoxFit.contain,
            ),
            Image.network(
              'https://media.giphy.com/media/vkUoDJyrhhBcQy6Klb/giphy.gif',
              fit: BoxFit.contain,
            ),
            Image.network(
              'https://cdn.discordapp.com/attachments/554896306863341568/789406160372891658/rainbow.gif',
              fit: BoxFit.contain,
            ),
            Text(''),
            Text(''),
            Text(''),
            GestureDetector(
              onTap: () => login,
              child: Container(
                width: 260.0,
                height: 60.0,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black87,
                      blurRadius: 25,
                      offset: const Offset(0, 0),
                    ),
                  ],
                  color: Colors.orangeAccent[100],
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40),
                      bottomLeft: Radius.circular(40),
                      bottomRight: Radius.circular(40)),
                  image: DecorationImage(
                    image: AssetImage(
                      'assets/images/google_signin_button.png',
                    ),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return isAuth ? buildAuthScreen() : buildUnAuthScreen();
  }
}
