import 'package:flutter/material.dart';

circularProgress() {
  return Text("circular progress");
}

linearProgress() {
  return Text("linear progress");
}
