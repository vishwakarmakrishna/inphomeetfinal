import 'package:flutter/material.dart';
import 'package:inphomeet/pages/home.dart';
import 'package:inphomeet/pages/home.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'InPhoMeet',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'transformers',
        primarySwatch: Colors.yellow,
        accentColor: Colors.deepOrangeAccent,
      ),
      home: Home(),
    );
  }
}
